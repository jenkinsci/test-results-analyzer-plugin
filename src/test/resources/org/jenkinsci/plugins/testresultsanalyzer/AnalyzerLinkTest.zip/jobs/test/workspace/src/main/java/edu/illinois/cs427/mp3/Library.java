package edu.illinois.cs427.mp3;

import com.thoughtworks.xstream.XStream;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Container class for all the collections (that eventually contain books).
 * Its main responsibility is to save the collections to a file and restore them from a file.
 */
public final class Library {
    private List<Collection> collections;

    /**
     * Builds a new, empty library.
     */
    public Library() {
        collections = new ArrayList<Collection>();
    }

    /**
     * Builds a new library and restores its contents from the given file.
     *
     * @param fileName the file from where to restore the library.
     */
    public Library(String fileName) throws IOException {
        XStream xStream = new XStream();
        xStream.alias("book", Book.class);
        xStream.alias("collection", Collection.class);
        xStream.alias("library", Library.class);

        File file = new File(fileName);

        InputStream inputStream = new FileInputStream(file);
        Library deserializedLibrary;

        deserializedLibrary = (Library) xStream.fromXML(inputStream);

        this.collections = deserializedLibrary.collections;

        inputStream.close();
    }

    /**
     * Saved the contents of the library to the given file.
     *
     * @param fileName the file where to save the library
     */
    public void saveLibraryToFile(String fileName) throws IOException {
        XStream xStream = new XStream();
        xStream.alias("book", Book.class);
        xStream.alias("collection", Collection.class);
        xStream.alias("library", Library.class);

        OutputStream outputStream = new FileOutputStream(fileName);
        OutputStreamWriter writer = new OutputStreamWriter(outputStream, Charset.forName("UTF-8"));
        xStream.toXML(this, writer);

        outputStream.close();
        writer.close();
    }

    /**
     * Returns the collections contained in the library.
     *
     * @return library contained elements
     */
    public List<Collection> getCollections() {
        return collections;
    }
}
