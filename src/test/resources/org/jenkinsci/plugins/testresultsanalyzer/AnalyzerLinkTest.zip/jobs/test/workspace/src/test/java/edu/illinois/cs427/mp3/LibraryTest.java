package edu.illinois.cs427.mp3;

import org.junit.AfterClass;
import org.junit.Test;
import org.unitils.thirdparty.org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InvalidClassException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

public class LibraryTest {
    @Test
    public void testLibraryConstructorFromFile1() {
        Collection fictionCollection = new Collection("Fiction");
        Collection nonfictionCollection = new Collection("Non-Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection mysteryCollection = new Collection("Mystery Collection");
        Collection murderMysteryCollection = new Collection("Murder Mystery");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");
        Book bookDune = new Book("Dune", "Frank Herbert");

        Book book1 = new Book("Why Not Me?", "Mindy Kaling");
        Book book2 = new Book("The Life-Changing Magic of Tidying Up: The Japanese Art of Decluttering and Organizing", "Marie Kondo");

        nonfictionCollection.addElement(book1);
        nonfictionCollection.addElement(book2);

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);
        scienceFictionCollection.addElement(bookDune);
        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.addElement(mysteryCollection);
        mysteryCollection.addElement(murderMysteryCollection);


        List<Collection> expectedCollections = new ArrayList<>();
        expectedCollections.add(fictionCollection);
        expectedCollections.add(nonfictionCollection);

        String path = "./src/test/resources/testLibrary1.xml";

        //act
        Library restoredLibrary = null;
        try {
            restoredLibrary = new Library(path);
        } catch (FileNotFoundException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }

        //assert
        assertReflectionEquals(expectedCollections, restoredLibrary.getCollections());
    }

    @Test
    //invalid path
    public void testLibraryConstructorFromFile2() {
        String path = "$&$#&..*$%~@~!!/#.^@#^!#^%..../@#^#@.xml";

        try {
            Library restoredLibrary = new Library(path);
            assertFalse(true);
        } catch (FileNotFoundException e) {
            assertTrue(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test
    //non-existant path
    public void testLibraryConstructorFromFile3() {
        String path = "/NOTAREALPATH/SERIOUSLYITDOESNTREALLYEXIST/PLEASEDONTMAKETHISFAIL/YOUCOULDTECHNICALLYHAVETHISPATH/ITSALWAYS/A/Possibility1/But/Al/so/N/o/t/very/likely/sadface.xml";

        try {
            Library restoredLibrary = new Library(path);
            assertFalse(true);
        } catch (FileNotFoundException e) {
            assertTrue(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test
    //empty library
    public void testLibraryConstructorFromFile4() {
        String path = "./src/test/resources/testLibrary4.xml";
        Library expectedLibrary = new Library();

        //act
        Library restoredLibrary = null;
        try {
            restoredLibrary = new Library(path);
        } catch (FileNotFoundException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }

        //assert
        assertReflectionEquals(expectedLibrary, restoredLibrary);
    }

    @Test(expected = Exception.class)
    //invalid file
    public void testLibraryConstructorFromFile5() {
        String path = "./src/test/resources/testLibrary5.xml";

        try {
            Library restoredLibrary = new Library(path);
        } catch (InvalidClassException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test(expected = Exception.class)
    //extra property
    public void testLibraryConstructorFromFile6() {
        String path = "./src/test/resources/testLibrary6.xml";

        try {
            Library restoredLibrary = new Library(path);
        } catch (InvalidClassException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test
    //Save empty library
    public void testSaveLibraryToFile1() {
        Library mainLibrary = new Library();

        File saveFile = new File("./src/test/resources/saveTest1.xml");
        String absolutePath = saveFile.getAbsolutePath();

        String expectedContents = "<library>\n" +
                "  <collections/>\n" +
                "</library>";

        //act
        try {
            mainLibrary.saveLibraryToFile(absolutePath);
        } catch (FileNotFoundException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }

        String fileContents = "";
        try {
            fileContents = FileUtils.readFileToString(saveFile, "UTF-8");
        } catch (IOException e) {
            assertFalse(true);
        }

        //assert
        assertTrue(saveFile.exists());
        assertEquals(expectedContents, fileContents);
    }

    @Test
    //invalid path
    public void testSaveLibraryToFile2() {
        String path = "$&$#&..*$%~@~!!/#.^@#^!#^%..../@#^#@.xml";

        Library mainLibrary = new Library();

        try {
            mainLibrary.saveLibraryToFile(path);
            assertFalse(true);
        } catch (FileNotFoundException e) {
            assertTrue(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test
    //non-existant path
    public void testSaveLibraryToFile3() {
        String path = "/NOTAREALPATH/SERIOUSLYITDOESNTREALLYEXIST/PLEASEDONTMAKETHISFAIL/YOUCOULDTECHNICALLYHAVETHISPATH/ITSALWAYS/A/Possibility1/But/Al/so/N/o/t/very/likely/sadface.xml";

        Library mainLibrary = new Library();

        try {
            mainLibrary.saveLibraryToFile(path);
            assertFalse(true);
        } catch (FileNotFoundException e) {
            assertTrue(true);
        } catch (IOException e) {
            assertFalse(true);
        }
    }

    @Test
    //non-existant path
    public void testSaveLibraryToFile4()
    {
        String loadPath = "./src/test/resources/testLibrary1.xml";
        String savePath = "./src/test/resources/saveTest4.xml";
        File saveFile = new File(savePath);
        String expectedContents = "<library>\n" +
                "  <collections>\n" +
                "    <collection>\n" +
                "      <elements>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Harry Potter 1</title>\n" +
                "          <author>J.K. Rowling</author>\n" +
                "        </book>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Harry Potter 2</title>\n" +
                "          <author>J.K. Rowling</author>\n" +
                "        </book>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Harry Potter 3</title>\n" +
                "          <author>J.K. Rowling</author>\n" +
                "        </book>\n" +
                "        <collection>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <elements>\n" +
                "            <book>\n" +
                "              <parentCollection reference=\"../../..\"/>\n" +
                "              <title>Dune</title>\n" +
                "              <author>Frank Herbert</author>\n" +
                "            </book>\n" +
                "            <book>\n" +
                "              <parentCollection reference=\"../../..\"/>\n" +
                "              <title>I, Robot</title>\n" +
                "              <author>Isaac Asimov</author>\n" +
                "            </book>\n" +
                "          </elements>\n" +
                "          <name>Science Fiction</name>\n" +
                "        </collection>\n" +
                "        <collection>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <elements>\n" +
                "            <collection>\n" +
                "              <parentCollection reference=\"../../..\"/>\n" +
                "              <elements/>\n" +
                "              <name>Murder Mystery</name>\n" +
                "            </collection>\n" +
                "          </elements>\n" +
                "          <name>Mystery Collection</name>\n" +
                "        </collection>\n" +
                "      </elements>\n" +
                "      <name>Fiction</name>\n" +
                "    </collection>\n" +
                "    <collection>\n" +
                "      <elements>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Why Not Me?</title>\n" +
                "          <author>Mindy Kaling</author>\n" +
                "        </book>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>The Life-Changing Magic of Tidying Up: The Japanese Art of Decluttering and Organizing</title>\n" +
                "          <author>Marie Kondo</author>\n" +
                "        </book>\n" +
                "      </elements>\n" +
                "      <name>Non-Fiction</name>\n" +
                "    </collection>\n" +
                "  </collections>\n" +
                "</library>";

        //act
        Library restoredLibrary = null;
        try {
            restoredLibrary = new Library(loadPath);
        } catch (FileNotFoundException e) {
            assertFalse(true);
        } catch (IOException e) {
            assertFalse(true);
        }

        Collection tmp = (Collection) restoredLibrary.getCollections().get(0).getElements().get(3);
        tmp.addElement(new Book("I, Robot", "Isaac Asimov"));

        try {
            restoredLibrary.saveLibraryToFile(savePath);
        } catch (IOException e) {
            assertFalse(true);
        }

        String fileContents = "";
        try {
            fileContents = FileUtils.readFileToString(saveFile, "UTF-8");
        } catch (IOException e) {
            assertFalse(true);
        }

        assertEquals(expectedContents, fileContents);
    }

    @AfterClass
    //cleanup method to delete any created Files
    public static void deleteGeneratesFiles() {
        //safe delete
        ArrayList<File> filesToDelete = new ArrayList<File>();
        filesToDelete.add(new File("./src/test/resources/saveTest1.xml"));
        filesToDelete.add(new File("./src/test/resources/saveTest4.xml"));

        for (File file : filesToDelete) {
            boolean wasDeleted = file.delete();
        }
    }

}
