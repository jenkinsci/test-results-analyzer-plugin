package edu.illinois.cs427.mp3;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

public class CollectionTest {
    @Test
    //Collection with no elements
    public void testRestoreCollection1() {
        String xml = "<collection>\n" +
                "  <elements/>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection restoredCollection = Collection.restoreCollection(xml);

        //assert
        assertEquals("Fiction", restoredCollection.getName());
        assertEquals(new ArrayList<Collection>(), restoredCollection.getElements());
    }

    @Test
    //Collection with Books and Collections
    public void testRestoreCollection2() {
        String xml = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 1</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 2</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 3</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <collection>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <elements>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Dune</title>\n" +
                "          <author>Frank Herbert</author>\n" +
                "        </book>\n" +
                "      </elements>\n" +
                "      <name>Science Fiction</name>\n" +
                "    </collection>\n" +
                "    <collection>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <elements>\n" +
                "        <collection>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <elements/>\n" +
                "          <name>Murder Mystery</name>\n" +
                "        </collection>\n" +
                "      </elements>\n" +
                "      <name>Mystery Collection</name>\n" +
                "    </collection>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection mysteryCollection = new Collection("Mystery Collection");
        Collection murderMysteryCollection = new Collection("Murder Mystery");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");
        Book bookDune = new Book("Dune", "Frank Herbert");

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);
        scienceFictionCollection.addElement(bookDune);
        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.addElement(mysteryCollection);
        mysteryCollection.addElement(murderMysteryCollection);

        //act
        Collection restoredCollection = Collection.restoreCollection(xml);

        //assert
        assertEquals("Fiction", restoredCollection.getName());
        assertReflectionEquals(fictionCollection, restoredCollection);
    }

    @Test
    //Single book inside of collection, test getParent and getContaining
    public void testRestoreCollection3() {
        String xml = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");
        fictionCollection.addElement(harryPotterBook);

        //act
        Collection restoredCollection = Collection.restoreCollection(xml);

        //assert
        assertEquals("Fiction", restoredCollection.getName());

        Book restoredBook = (Book) restoredCollection.getElements().get(0);
        List<Collection> expectedContainedCollections = new ArrayList<>();
        expectedContainedCollections.add(restoredCollection);

        assertEquals(expectedContainedCollections, restoredBook.getContainingCollections());
        assertEquals(restoredCollection, restoredBook.getParentCollection());
        assertReflectionEquals(fictionCollection, restoredCollection);
    }

    @Test
    //restore multiple books in a collection
    public void testRestoreCollection4() {
        String xml = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 1</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 2</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 3</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);

        //act
        Collection restoredCollection = Collection.restoreCollection(xml);

        //assert
        assertEquals("Fiction", restoredCollection.getName());
        assertReflectionEquals(fictionCollection, restoredCollection);
    }

    @Test(expected = Exception.class)
    //invalid string
    public void testRestoreCollection5()
    {
        String xml = "<invalidxml><>";

        Collection restoredCollection = Collection.restoreCollection(xml);
    }

    @Test(expected = Exception.class)
    //additional properties
    public void testRestoreCollection6()
    {
        String xml = "<collection>\n" +
                "  <elements/>\n" +
                "  <name>Fiction</name>\n" +
                "  <someotherattribute>False</someotherattribute>\n" +
                "</collection>";

        Collection restoredCollection = Collection.restoreCollection(xml);
    }

    @Test
    //representation of single book in collection
    public void testGetStringRepresentation1() {
        //arrange
        Collection fictionCollection = new Collection("Fiction");
        String expectedXmlRepresentation = "<collection>\n" +
                "  <elements/>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        //act
        String collectionRepresentation = fictionCollection.getStringRepresentation();

        //assert
        assertEquals(expectedXmlRepresentation, collectionRepresentation);
    }

    @Test
    //representation of single book in collection
    public void testGetStringRepresentation2() {
        //arrange
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");
        fictionCollection.addElement(harryPotterBook);

        String expectedXmlRepresentation = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        //act
        String collectionRepresentation = fictionCollection.getStringRepresentation();

        //assert
        assertEquals(expectedXmlRepresentation, collectionRepresentation);
    }

    @Test
    //representation of nested with parents/grandparents
    public void testGetStringRepresentation3() {
        String expectedXmlRepresentation = "<collection>\n" +
                "  <elements>\n" +
                "    <collection>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <elements>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Dune</title>\n" +
                "          <author>Frank Herbert</author>\n" +
                "        </book>\n" +
                "      </elements>\n" +
                "      <name>Science Fiction</name>\n" +
                "    </collection>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Book bookDune = new Book("Dune", "Frank Herbert");

        fictionCollection.addElement(scienceFictionCollection);
        scienceFictionCollection.addElement(bookDune);

        //act
        String collectionRepresentation = fictionCollection.getStringRepresentation();

        //assert
        assertEquals(expectedXmlRepresentation, collectionRepresentation);
    }

    @Test
    //representation of multiple books in a collection
    public void testGetStringRepresentation4() {
        String expectedXmlRepresentation = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 1</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 2</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 3</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);

        //act
        String collectionRepresentation = fictionCollection.getStringRepresentation();

        //assert
        assertEquals(expectedXmlRepresentation, collectionRepresentation);
    }

    @Test
    //representation of collection with books and collections
    public void testGetStringRepresentation5() {
        String expectedXmlRepresentation = "<collection>\n" +
                "  <elements>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 1</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 2</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <book>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <title>Harry Potter 3</title>\n" +
                "      <author>J.K. Rowling</author>\n" +
                "    </book>\n" +
                "    <collection>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <elements>\n" +
                "        <book>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <title>Dune</title>\n" +
                "          <author>Frank Herbert</author>\n" +
                "        </book>\n" +
                "      </elements>\n" +
                "      <name>Science Fiction</name>\n" +
                "    </collection>\n" +
                "    <collection>\n" +
                "      <parentCollection reference=\"../../..\"/>\n" +
                "      <elements>\n" +
                "        <collection>\n" +
                "          <parentCollection reference=\"../../..\"/>\n" +
                "          <elements/>\n" +
                "          <name>Murder Mystery</name>\n" +
                "        </collection>\n" +
                "      </elements>\n" +
                "      <name>Mystery Collection</name>\n" +
                "    </collection>\n" +
                "  </elements>\n" +
                "  <name>Fiction</name>\n" +
                "</collection>";

        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection mysteryCollection = new Collection("Mystery Collection");
        Collection murderMysteryCollection = new Collection("Murder Mystery");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");
        Book bookDune = new Book("Dune", "Frank Herbert");

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);
        scienceFictionCollection.addElement(bookDune);
        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.addElement(mysteryCollection);
        mysteryCollection.addElement(murderMysteryCollection);

        //act
        String collectionRepresentation = fictionCollection.getStringRepresentation();

        //assert
        assertEquals(expectedXmlRepresentation, collectionRepresentation);
    }

    @Test
    //simple test add
    public void testAddElement1() {
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");

        boolean wasAdded = fictionCollection.addElement(harryPotterBook);
        List<Element> expectedCollection = new ArrayList<Element>();
        expectedCollection.add(harryPotterBook);

        assertTrue(wasAdded);
        assertEquals(expectedCollection, fictionCollection.getElements());
        assertEquals(fictionCollection, harryPotterBook.getParentCollection());
    }

    @Test(expected = IllegalStateException.class)
    //add collection to itself
    public void testAddElement2() {
        Collection fictionCollection = new Collection("Fiction");

        fictionCollection.addElement(fictionCollection);
    }

    @Test
    //add book that already has parent
    public void testAddElement3() {
        Collection fictionCollection = new Collection("Fiction");
        Collection adventureCollection = new Collection("Adventure");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");

        boolean wasAddedToFiction = fictionCollection.addElement(harryPotterBook);
        boolean wasAddedToAdventure = adventureCollection.addElement(harryPotterBook);

        assertTrue(wasAddedToFiction);
        assertFalse(wasAddedToAdventure);
        assertTrue(fictionCollection.getElements().contains(harryPotterBook));
        assertFalse(adventureCollection.getElements().contains(harryPotterBook));
    }

    @Test
    //add same book twice
    public void testAddElement4() {
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");

        List<Element> expectedElements = new ArrayList<>();
        expectedElements.add(harryPotterBook);

        //act
        boolean wasAdded1 = fictionCollection.addElement(harryPotterBook);
        boolean wasAdded2 = fictionCollection.addElement(harryPotterBook);

        //assert
        assertTrue(wasAdded1);
        assertFalse(wasAdded2);
        assertEquals(expectedElements, fictionCollection.getElements());
        assertEquals(fictionCollection, harryPotterBook.getParentCollection());
    }

    @Test
    //add same collection twice
    public void testAddElement5() {
        Collection fictionCollection = new Collection("Fiction");
        Collection adventureCollection = new Collection("Adventure");

        List<Element> expectedElements = new ArrayList<>();
        expectedElements.add(adventureCollection);

        //act
        boolean wasAdded1 = fictionCollection.addElement(adventureCollection);
        boolean wasAdded2 = fictionCollection.addElement(adventureCollection);

        //assert
        assertTrue(wasAdded1);
        assertFalse(wasAdded2);
        assertEquals(expectedElements, fictionCollection.getElements());
        assertEquals(fictionCollection, adventureCollection.getParentCollection());
    }

    @Test
    //add collection that already has parent
    public void testAddElement6() {
        Collection fictionCollection = new Collection("Fiction");
        Collection adventureCollection = new Collection("Adventure");
        Collection adventureFictionCollection = new Collection("Adventure-Fiction");

        boolean wasAddedToFiction = fictionCollection.addElement(adventureFictionCollection);
        boolean wasAddedToAdventure = adventureCollection.addElement(adventureFictionCollection);

        assertTrue(wasAddedToFiction);
        assertFalse(wasAddedToAdventure);
        assertTrue(fictionCollection.getElements().contains(adventureFictionCollection));
        assertFalse(adventureCollection.getElements().contains(adventureFictionCollection));
    }

    @Test
    //add collection of same name to collection
    public void testAddElement7()
    {
        Collection fictionCollection1 = new Collection("Fiction");
        Collection fictionCollection2 = new Collection("Fiction");

        boolean wasAdded = fictionCollection1.addElement(fictionCollection2);

        assertTrue(wasAdded);
    }

    @Test
    //Delete Single Book
    public void testDeleteElement1() {
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook = new Book("Harry Potter", "J.K. Rowling");

        boolean wasAdded = fictionCollection.addElement(harryPotterBook);
        boolean wasDeleted = fictionCollection.deleteElement(harryPotterBook);

        assertTrue(wasAdded);
        assertTrue(wasDeleted);
        assertEquals(new ArrayList<Element>(), fictionCollection.getElements());
        assertEquals(null, harryPotterBook.getParentCollection());
        assertFalse(fictionCollection.elements.contains(harryPotterBook));
    }

    @Test
    //Delete Multiple Books
    public void testDeleteElement2() {
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");

        boolean wasBook1Added = fictionCollection.addElement(harryPotterBook1);
        boolean wasBook2Added = fictionCollection.addElement(harryPotterBook2);
        boolean wasBook3Added = fictionCollection.addElement(harryPotterBook3);

        List<Element> expectedCollection = new ArrayList<Element>();
        expectedCollection.add(harryPotterBook3);

        boolean wasBook1Deleted = fictionCollection.deleteElement(harryPotterBook1);
        boolean wasBook2Deleted = fictionCollection.deleteElement(harryPotterBook2);

        assertTrue(wasBook1Added);
        assertTrue(wasBook2Added);
        assertTrue(wasBook3Added);
        assertTrue(wasBook1Deleted);
        assertTrue(wasBook2Deleted);
        assertEquals(expectedCollection, fictionCollection.getElements());
        assertEquals(null, harryPotterBook1.getParentCollection());
        assertEquals(null, harryPotterBook2.getParentCollection());
        assertFalse(fictionCollection.elements.contains(harryPotterBook1));
        assertFalse(fictionCollection.elements.contains(harryPotterBook2));
        assertTrue(fictionCollection.elements.contains(harryPotterBook3));
    }

    @Test
    //Delete Non-Existent Book
    public void testDeleteElement3() {
        Collection fictionCollection = new Collection("Fiction");
        Book harryPotterBook1 = new Book("Harry Potter 1", "J.K. Rowling");
        Book harryPotterBook2 = new Book("Harry Potter 2", "J.K. Rowling");
        Book harryPotterBook3 = new Book("Harry Potter 3", "J.K. Rowling");
        Book harryPotterBook4 = new Book("Harry Potter 4", "J.K. Rowling");

        fictionCollection.addElement(harryPotterBook1);
        fictionCollection.addElement(harryPotterBook2);
        fictionCollection.addElement(harryPotterBook3);

        List<Element> expectedCollection = new ArrayList<Element>();
        expectedCollection.add(harryPotterBook3);

        boolean wasBook4Deleted = fictionCollection.deleteElement(harryPotterBook4);

        assertFalse(wasBook4Deleted);
    }

    @Test
    //Delete Single Collection
    public void testDeleteElement4() {
        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");

        boolean wasAdded = fictionCollection.addElement(scienceFictionCollection);
        boolean wasDeleted = fictionCollection.deleteElement(scienceFictionCollection);

        assertTrue(wasAdded);
        assertTrue(wasDeleted);
        assertEquals(new ArrayList<Element>(), fictionCollection.getElements());
        assertEquals(null, scienceFictionCollection.getParentCollection());
        assertFalse(fictionCollection.elements.contains(scienceFictionCollection));
    }

    @Test
    //Delete Single Collection with Books
    public void testDeleteElement5() {
        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Book bookDune = new Book("Dune", "Frank Herbert");

        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.deleteElement(scienceFictionCollection);
        scienceFictionCollection.addElement(bookDune);

        assertEquals(new ArrayList<Element>(), fictionCollection.getElements());
        assertEquals(null, scienceFictionCollection.getParentCollection());
        assertEquals(scienceFictionCollection, bookDune.getParentCollection());
        assertFalse(fictionCollection.elements.contains(scienceFictionCollection));
        assertTrue(scienceFictionCollection.elements.contains(bookDune));
    }

    @Test
    //Delete Multiple Collections
    public void testDeleteElement6() {
        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection horrorCollection = new Collection("Horror");
        Collection fantasyCollection = new Collection("Fantasy");

        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.addElement(horrorCollection);
        fictionCollection.addElement(fantasyCollection);

        boolean wasScienceFictionDeleted = fictionCollection.deleteElement(scienceFictionCollection);
        boolean wasHorrorDeleted = fictionCollection.deleteElement(horrorCollection);

        assertTrue(wasScienceFictionDeleted);
        assertTrue(wasHorrorDeleted);

        List<Element> expectedCollection = new ArrayList<>();
        expectedCollection.add(fantasyCollection);

        assertEquals(expectedCollection, fictionCollection.getElements());
        assertEquals(null, scienceFictionCollection.getParentCollection());
        assertEquals(null, horrorCollection.getParentCollection());
        assertEquals(fictionCollection, fantasyCollection.getParentCollection());
        assertFalse(fictionCollection.elements.contains(scienceFictionCollection));
        assertFalse(fictionCollection.elements.contains(horrorCollection));
        assertTrue(fictionCollection.elements.contains(fantasyCollection));
    }

    @Test
    //Delete Multiple Collections with Books
    public void testDeleteElement7() {
        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection horrorCollection = new Collection("Horror");
        Collection fantasyCollection = new Collection("Fantasy");

        Book gameOfThrones = new Book("A Song of Ice and Fire", "George R. R. Martin");
        Book theMartian = new Book("The Martian", "Andy Weir");
        Book harryPotter = new Book("Harry Potter", "J.K. Rowling");

        fictionCollection.addElement(harryPotter);
        fictionCollection.addElement(scienceFictionCollection);
        scienceFictionCollection.addElement(theMartian);
        fictionCollection.addElement(horrorCollection);
        fantasyCollection.addElement(gameOfThrones);
        fictionCollection.addElement(fantasyCollection);

        //act
        boolean wasSciFiCollectionDeleted = fictionCollection.deleteElement(scienceFictionCollection);
        boolean wasFantasyCollectionDeleted = fictionCollection.deleteElement(fantasyCollection);
        boolean wasHarryPotterDeleted = fictionCollection.deleteElement(harryPotter);

        assertTrue(wasFantasyCollectionDeleted);
        assertTrue(wasHarryPotterDeleted);
        assertTrue(wasSciFiCollectionDeleted);
    }

    @Test
    //Delete Non-Existent Collections
    public void testDeleteElement8() {
        Collection fictionCollection = new Collection("Fiction");
        Collection scienceFictionCollection = new Collection("Science Fiction");
        Collection horrorCollection = new Collection("Horror");
        Collection fantasyCollection = new Collection("Fantasy");

        fictionCollection.addElement(scienceFictionCollection);
        fictionCollection.addElement(horrorCollection);

        boolean wasScienceFictionDeleted = fictionCollection.deleteElement(scienceFictionCollection);
        boolean wasHorrorDeleted = fictionCollection.deleteElement(horrorCollection);
        boolean wasFantasyDeleted = fictionCollection.deleteElement(fantasyCollection);

        assertTrue(wasScienceFictionDeleted);
        assertTrue(wasHorrorDeleted);
        assertFalse(wasFantasyDeleted);
    }

    @Test
    //Delete from empty Collection
    public void testDeleteElement9() {
        Collection fictionCollection = new Collection("Fiction");

        Collection fantasyCollection = new Collection("Fantasy");
        Book gameOfThrones = new Book("A Song of Ice and Fire", "George R. R. Martin");

        //act
        boolean wasCollectionDeleted = fictionCollection.deleteElement(fantasyCollection);
        boolean wasBookDeleted = fictionCollection.deleteElement(gameOfThrones);

        assertFalse(wasCollectionDeleted);
        assertFalse(wasBookDeleted);
    }

    @Test
    //Delete book and collection multiple times
    public void testDeleteElement10() {
        Collection fictionCollection = new Collection("Fiction");
        Collection fantasyCollection = new Collection("Fantasy");
        Book gameOfThrones = new Book("A Song of Ice and Fire", "George R. R. Martin");

        fictionCollection.addElement(gameOfThrones);
        fictionCollection.addElement(fantasyCollection);

        //act
        boolean wasCollectionDeleted1 = fictionCollection.deleteElement(fantasyCollection);
        boolean wasCollectionDeleted2 = fictionCollection.deleteElement(fantasyCollection);
        boolean wasCollectionDeleted3 = fictionCollection.deleteElement(fantasyCollection);
        boolean wasCollectionDeleted4 = fictionCollection.deleteElement(fantasyCollection);

        boolean wasBookDeleted1 = fictionCollection.deleteElement(gameOfThrones);
        boolean wasBookDeleted2 = fictionCollection.deleteElement(gameOfThrones);

        assertTrue(wasCollectionDeleted1);
        assertFalse(wasCollectionDeleted2);
        assertFalse(wasCollectionDeleted3);
        assertFalse(wasCollectionDeleted4);

        assertTrue(wasBookDeleted1);
        assertFalse(wasBookDeleted2);
    }
}